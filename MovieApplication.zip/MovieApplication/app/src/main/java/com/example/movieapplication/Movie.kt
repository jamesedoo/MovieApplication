package com.example.movieapplication

data class Movie(
    var movieName: String,
    var movieImg: Int
)